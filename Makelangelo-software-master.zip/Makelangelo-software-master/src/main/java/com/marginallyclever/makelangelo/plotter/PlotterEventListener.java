package com.marginallyclever.makelangelo.plotter;

public interface PlotterEventListener {
	void plotterEvent(PlotterEvent e);
}
