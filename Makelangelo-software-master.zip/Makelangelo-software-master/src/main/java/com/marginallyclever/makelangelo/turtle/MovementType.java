package com.marginallyclever.makelangelo.turtle;

@Deprecated(since="7.70.0", forRemoval=true)
public enum MovementType {
    TRAVEL, // move without drawing
    DRAW_LINE, // move while drawing
    TOOL_CHANGE
}
