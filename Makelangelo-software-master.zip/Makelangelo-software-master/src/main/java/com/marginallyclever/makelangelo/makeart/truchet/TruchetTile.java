package com.marginallyclever.makelangelo.makeart.truchet;

/**
 * A single Truchet tile.
 */
public interface TruchetTile {
    void drawTile(double x,double y);
}
