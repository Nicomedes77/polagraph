package com.marginallyclever.communications;


public interface NetworkSessionListener {
	public void networkSessionEvent(NetworkSessionEvent evt);
}
